export default function show30News(moreNews){
    document.querySelector('button.button.more').addEventListener('click', moreNews)
}