import getFromApi from './API/API';
import createNews from './news/news';
import show30News from './button/button'; 

import './styles/style.scss';

getFromApi().then(parseJson).catch(e => console.log(e));

const store = {}; 

function parseJson(stories){
    console.log(stories)
   store.stories = stories;
   store.stories.forEach((stories)=> createNews(stories))
}

console.log(store,"store");
var x=0;

function moreNews(){
    console.log(x += 30);
    return x;
}
console.log(x, "from scope")
show30News(moreNews)